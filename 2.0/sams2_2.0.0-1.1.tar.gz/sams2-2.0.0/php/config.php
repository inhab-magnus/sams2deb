<?php $configfile="/etc/sams2.conf"; ?>
